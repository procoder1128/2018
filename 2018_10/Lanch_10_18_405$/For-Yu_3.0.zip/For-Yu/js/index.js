 /* 
See https://codepen.io/MarcelSchulz/full/lCvwq

The effect doens't appear as nice when viewing in split view :-)

Fully working version can also be found at (http://schulzmarcel.de/x/drafts/parallax).

*/


jQuery(document).ready(function(){
    jQuery(window).scroll(function(e){
        parallaxScroll();
        bubbles()
    });

	function parallaxScroll(){
		var scrolled = $(window).scrollLeft();
        jQuery('.cloud-bg ').css('left',(0-(scrolled*.2))+'px');
        jQuery('.hills').css('left',(0-(scrolled*.1))+'px');
	}



});