var app = angular.module("app", []);
var markers = [];
var river = '';
var lat = 0;//picked lat
var long = 0;//picked long
var global_miles = 0; //picked miles

function setPickedPoint(r, la, lo, global_m) {
    river = r;
    lat = la;
    long = lo;
    global_miles = global_m;
    $('#lat').text(la);
    $('#lng').text(lo);
    $('#river').text(r);
    $('#miles').text(global_m);
    $('input[type="number"]').val(global_m);

}


app.controller("appCtrl", function ($scope, $http) {
    $scope.miles = 0;
    var miles = 0;


    $scope.validation = function () {
        removeAllMarkersOnMap();
        miles = $scope.miles;
        if (0 > miles || miles > 2333) {
            $scope.miles = 2333;
        }
        $scope.miles == null ? findPoint(0) : findPoint($scope.miles);
        global_miles = $scope.miles;
    };


    function removeAllMarkersOnMap() {
        for (var i = 0; i < markers.length; i++) {
            markers[i].setMap(null);
        }
    }

    function findPoint(miles) {
        var infoWindow = new google.maps.InfoWindow;
        var marker;
        $.each(global_rivermile, function (i, row) {
            var inputMile = parseInt(miles);
            var riverMile = parseInt(row.River_Mile.trim());

            if (inputMile < riverMile) {

                marker = new google.maps.Marker(
                    {
                        position: new google.maps.LatLng(row.Lat, row.Long),
                        map: map,
                    }
                );
                marker.setIcon("markers/back.png");
                google.maps.event.addListener(marker, 'click', (function (a, i) {
                    return function () {
                        setPickedPoint(row.River, row.Lat, row.Long, row.River_Mile);
                        infoWindow.setContent(whiteBox(row));
                        infoWindow.open(map, a);
                        map.panTo(new google.maps.LatLng(row.Lat, row.Long));
                    }
                })(marker, i));


                markers[i] = marker;
            } else if (riverMile == inputMile) {

                marker = new google.maps.Marker(
                    {
                        position: new google.maps.LatLng(row.Lat, row.Long),
                        map: map,
                    }
                );

                marker.setAnimation(google.maps.Animation.BOUNCE);
                map.panTo(new google.maps.LatLng(row.Lat, row.Long));
                marker.setIcon("");
                markers[i] = marker;


                google.maps.event.addListener(marker, 'click', (function (a, i) {
                    return function () {
                        setPickedPoint(row.River, row.Lat, row.Long, row.River_Mile);
                        infoWindow.setContent(whiteBox(row));
                        infoWindow.open(map, a);
                        map.panTo(new google.maps.LatLng(row.Lat, row.Long));
                    }
                })(marker, i));

                setPickedPoint(row.River, row.Lat, row.Long, row.River_Mile);
             } else if (riverMile < inputMile) {

                marker = new google.maps.Marker(
                    {
                        position: new google.maps.LatLng(row.Lat, row.Long),
                        map: map,
                    }
                );
                marker.setIcon("markers/front.png");
                google.maps.event.addListener(marker, 'click', (function (a, i) {

                    return function () {
                        setPickedPoint(row.River, row.Lat, row.Long, row.River_Mile);

                        infoWindow.setContent(whiteBox(row));
                        infoWindow.open(map, a);
                        map.panTo(new google.maps.LatLng(row.Lat, row.Long));
                    }
                })(marker, i));

                markers[i] = marker;
            }


        });
    }

});
