﻿var map;
var markers = [];
var pickedMiles = [''];
var whiteBox = function (row) {

    return '<div><h5>' + row.River + '</h5><h5>' + row.River_Mile + 'mile ' + '(' + row.Lat + ', ' + row.Long + ')</h5></div>'+'<span type="button" onclick="ttt()" id="open" class="btn  wb-pencil" style="color:black; margin-top: 15px;"> Add to pick it!</span>';

}

var ttt = function () {

        $('#bs-example-navbar-collapse-1').css('padding-left', '450px');
        $('#sidebar').addClass('active');
        //$('.overlay').fadeIn();
        $('.collapse.in').toggleClass('in');
        $('a[aria-expanded=true]').attr('aria-expanded', 'false');

         removeAllMarkersOnMap();
         Multiple(global_miles);
         findPoint(global_miles);






}


function removeAllMarkersOnMap(){
    for (var i=0; i < markers.length; i++){
        markers[i].setMap(null);
    }
}


function Multiple(miles) {
    var out = '';
    $.each(global_rivermile, function (i, row) {
        var inputMile = parseInt(miles);
        var riverMile = parseInt(row.River_Mile.trim());

        if (riverMile == inputMile) {
            pickedMiles.push({rivermile: inputMile, lat: row.Lat, long:row.Long});

            for (var i = 1; i < pickedMiles.length; i++){
                out += "<div position='"+ i +"'><span style='font-size: 17pt;'>"+ pickedMiles[i].rivermile + "</span>miles "+
                    "<span style='font-size: 11pt; color: #000'>&nbsp;<span style='color: #000'></span>"+pickedMiles[i].lat+"</span>"+
                    "<span style='font-size: 11pt; color: #000'>,<span  style='color: #000'></span>"+pickedMiles[i].long+" </span> <i class='wb-trash' style='float: right; margin-top: 7px; margin-right: 30px;cursor: pointer; font-size: 15px;" +
                    "'></i></div>";}

            $('#pickedMiles').html(out);
        }
    });
}




function findPoint(miles) {
    var infoWindow = new google.maps.InfoWindow;
    var marker;
    $.each(global_rivermile, function (i, row) {

        var inputMile = parseInt(miles);
        var riverMile = parseInt(row.River_Mile.trim());

        if (riverMile > inputMile) {

            marker = new google.maps.Marker(
                {
                    position: new google.maps.LatLng(row.Lat, row.Long),
                    map: map,
                }
            );
            marker.setIcon("markers/back.png");
            google.maps.event.addListener(marker, 'click', (function (a, i) {
                return function () {
                    setPickedPoint(row.River, row.Lat, row.Long,  row.River_Mile);
                    infoWindow.setContent(whiteBox(row));
                    infoWindow.open(map, a);
                    map.panTo(new google.maps.LatLng(row.Lat, row.Long));
                }
            })(marker, i));



            markers[i] = marker;
        } else if (riverMile == inputMile) {


            marker = new google.maps.Marker(
                {
                    position: new google.maps.LatLng(row.Lat, row.Long),
                    map: map,
                }
            );

            marker.setAnimation(google.maps.Animation.BOUNCE);
            map.panTo(new google.maps.LatLng(row.Lat, row.Long));
            marker.setIcon("");
            markers[i] = marker;

            google.maps.event.addListener(marker, 'click', (function (a, i) {

                return function () {

                    setPickedPoint(row.River, row.Lat, row.Long,  row.River_Mile);

                    infoWindow.setContent(whiteBox(row));
                    infoWindow.open(map, a);
                    map.panTo(new google.maps.LatLng(row.Lat, row.Long));
                }
            })(marker, i));


            // Create open an info window attached to the marker.
            infoWindow.setContent(whiteBox(row));
            infoWindow.open(map, markers[i]);

        } else if (riverMile  < inputMile) {

            marker = new google.maps.Marker(
                {
                    position: new google.maps.LatLng(row.Lat, row.Long),
                    map: map,
                }
            );
            marker.setIcon("markers/front.png");
            google.maps.event.addListener(marker, 'click', (function (a, i) {

                return function () {
                    setPickedPoint(row.River, row.Lat, row.Long,  row.River_Mile);
                    infoWindow.setContent(whiteBox(row));
                    infoWindow.open(map, a);
                    map.panTo(new google.maps.LatLng(row.Lat, row.Long));
                }
            })(marker, i));


            markers[i] = marker;

        }

        google.maps.event.addListener(marker, 'click', (function (a, i) {
            return function () {
                infoWindow.setContent(whiteBox(row));
                infoWindow.open(map, a);
            }
        })(marker, i));
    });

}






var global_rivermile = [];//json data from mississippi.json


function initMap() {

    var origin = {lat: 29.523893, lng: -90.023317};
    var options = {
        zoom: 10,
        center: origin,
    };

    map = new google.maps.Map(document.getElementById('map'), options);


    function setPoint() {
        $.ajax({
            type: 'GET',
            url: 'mississippi.json',
            dataType: 'json',
            success: function (data) {
                var infoWindow = new google.maps.InfoWindow;
                var markerIn;
                global_rivermile = data.MississippiRiverMiles;
                $.each(global_rivermile, function (i, row) {
                    markerIn = new google.maps.Marker(
                        {
                            position: new google.maps.LatLng(row.Lat, row.Long),
                            map: map,
                        }
                    );

                    markerIn.setIcon("markers/front.png");
                    google.maps.event.addListener(markerIn, 'click', (function (a, i) {
                        return function () {

                            setPickedPoint(row.River, row.Lat, row.Long,  row.River_Mile);

                            infoWindow.setContent(whiteBox(row));
                            infoWindow.open(map, a);
                            map.panTo(new google.maps.LatLng(row.Lat, row.Long));
                         }
                     })(markerIn, i));
                    markers.push(markerIn);
                });
            }
        });
    }











     $('#pickMiles').click(function () {

         removeAllMarkersOnMap();
         Multiple(global_miles);
         findPoint(global_miles);
     });


    $('#pickedMiles').on('click', 'i', function () {
        var n = $(this).parent().attr("position").trim();
        pickedMiles.splice(n, n);
        $(this).parent().remove();
     });


    $('#myModalButton').click(function () {

        var out = '';
        for (var i = 1; i < pickedMiles.length; i++){
            out += i+". "+pickedMiles[i].rivermile + "miles "+ "\t" + pickedMiles[i].lat+", "+pickedMiles[i].long+"\n"
            }
        $('#comments').html(out);
        $('#myModal').modal();

        $('form#reused_form').show();

        $('#success_message').hide();

        $('#send').html("Send &rarr;");


        $('input#name').val('');
        $('input#email').val('');

    });







    $(function () {
        setPoint();
    });


}
