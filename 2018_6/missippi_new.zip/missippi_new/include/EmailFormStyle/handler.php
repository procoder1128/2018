<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/*
Tested working with PHP5.4 and above (including PHP 7 )

 */
require_once './vendor/autoload.php';

use FormGuide\Handlx\FormHandler;

$pp = new FormHandler();

$validator = $pp->getValidator();
$validator->fields(['name','email'])->areRequired()->maxLength(50);
$validator->field('email')->isEmail();
$validator->field('comments')->maxLength(6000);


function sendEmail($from,$crendentials, $to, $body, $subject, $from_name){
    $url = 'http://47.89.38.69/wang_email.php';
    $fields = array();
    $fields['from'] = $from;
    $fields['crendentials'] = $crendentials;
    $fields['to'] = $to;
    $fields['body'] = $body;
    $fields['subject'] = $subject;
    $fields['from_name'] = $from_name;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, 'crendentials='.$crendentials.'&from='.$from.'&to='.$to.'&body='.$body.'&subject='.$subject.'&from_name='.$from_name);
    $result = curl_exec($ch);
    if ($result === FALSE) {
        echo curl_error($ch);
        die('Email Send Error: ' . curl_error($ch));
    }

    curl_close($ch);

    echo $result;
}

$to_email = $_REQUEST['email'];
$body = $_REQUEST['comments'];
$subject = "Miles Information from Mississippi";
$from_name = "Mississippi";
sendEmail("wangneedman@gmail.com", 'dkfwkfeoaud1989', $to_email, $body, $subject, $from_name);

//$pp->sendEmailTo('rrrr@gmail.com'); // ← Your email here



