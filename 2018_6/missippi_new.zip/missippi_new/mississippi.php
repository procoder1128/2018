<?php
/**
 * @package Akismet
 */
/*
Plugin Name: Mississippi map
Plugin URI:
Description: This pl you sleep. To get started: activate the Akismet plugin and then go to your Akismet Settings page to set up your API key.
Version: 4.0.3
Author: Automattic
Author URI: 
License: GPLv2 or later
Text Domain: akismet
*/

function mississippiMap($atts)
{
    extract(shortcode_atts(array(
        'id' => ''
    ), $atts));

    $mapview = "<iframe style='width: 100%; height: 900px;' scrolling='no' src='" . plugin_dir_url(__FILE__) . "include/index.html' frameborder='0' allowfullscreen></iframe>";
    return $mapview;
}

add_shortcode('mississippimap', 'mississippiMap');